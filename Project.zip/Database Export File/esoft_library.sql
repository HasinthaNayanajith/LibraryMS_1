-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2022 at 07:47 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esoft_library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `AdminID` varchar(5) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Contact` varchar(10) NOT NULL,
  `RegDate` varchar(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`AdminID`, `FullName`, `Contact`, `RegDate`, `Email`, `Address`) VALUES
('A0001', 'Hasintha Nayanajith', '0775547473', '22-01-2022', 'hasintha@gmail.com', 'Matara Sri Lanka'),
('A0002', 'Manula Pabasara', '0752563984', '2022-01-22', 'manulapabasara@gmail.com', 'Kurunegala Sri Lanka'),
('A0003', 'Nirwan Abhishek', '0785147256', '11-Feb-2022', 'nirwan.info@gmail.com', 'Colombo Sri Lanka');

-- --------------------------------------------------------

--
-- Table structure for table `book_table`
--

CREATE TABLE `book_table` (
  `BookID` varchar(5) NOT NULL,
  `BookName` varchar(100) NOT NULL,
  `Author` varchar(100) NOT NULL,
  `RackNumber` varchar(10) NOT NULL,
  `RegDate` varchar(50) NOT NULL,
  `Availability` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_table`
--

INSERT INTO `book_table` (`BookID`, `BookName`, `Author`, `RackNumber`, `RegDate`, `Availability`) VALUES
('B0001', 'Robinson Crooso', 'JB Senanayake', 'A20', '22-01-2022', 'Out Of Library'),
('B0002', 'Vendor Of Sweets', 'RK Narayan', 'A05', '2022-01-25', 'In Library Premises'),
('B0003', 'Hathpana', 'Munidasa Kumarathunga', 'A05', '11-Feb-2022', 'In Library Premises'),
('B0004', 'Madolduwa', 'Martin Wickramasinghe', 'A01', '11-Feb-2022', 'In Library Premises'),
('B0005', '12.12.12', 'Manjula Senarathne', 'A02', '11-Feb-2022', 'In Library Premises');

-- --------------------------------------------------------

--
-- Table structure for table `issued_books`
--

CREATE TABLE `issued_books` (
  `BookID` varchar(5) NOT NULL,
  `MemberID` varchar(10) NOT NULL,
  `DateOfIssue` varchar(12) NOT NULL,
  `DateOfReturn` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issued_books`
--

INSERT INTO `issued_books` (`BookID`, `MemberID`, `DateOfIssue`, `DateOfReturn`) VALUES
('B0001', 'M0001', '11-Feb-2022', '2022-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `login_table`
--

CREATE TABLE `login_table` (
  `UserID` varchar(5) NOT NULL,
  `PWord` varchar(10) NOT NULL,
  `UserType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_table`
--

INSERT INTO `login_table` (`UserID`, `PWord`, `UserType`) VALUES
('A0001', '3036', 'Administrator'),
('A0002', '3036', 'Administrator'),
('A0003', '3036', 'Administrator'),
('M0001', 'keyboard', 'Library Member'),
('M0002', 'keyboard', 'Library Member'),
('M0003', 'keyboard', 'Library Member'),
('M0004', 'keyboard', 'Library Member'),
('M0005', 'keyboard', 'Library Member');

-- --------------------------------------------------------

--
-- Table structure for table `member_table`
--

CREATE TABLE `member_table` (
  `MemberID` varchar(5) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact` varchar(10) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `RegDate` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member_table`
--

INSERT INTO `member_table` (`MemberID`, `FullName`, `Address`, `Contact`, `Email`, `RegDate`) VALUES
('M0001', 'Charuka Nuwantha', 'Kalutara Sri Lanka', '0772060108', 'charuka@gmail.com', '21-01-2022'),
('M0002', 'Kaween Lakdinu', 'Negombo, Sri Lanka', '0374852245', 'kaween@yahoo.com', '22-01-2022'),
('M0003', 'Vimukthi Weligama', 'Hettipola', '0754896521', 'vimukthi@gmail.com', '11-Feb-2022'),
('M0004', 'Rashmika Keshan', 'Hettipola', '0745123698', 'rashmika@yahoo.com', '11-Feb-2022'),
('M0005', 'Irudi Adithya', 'Barampola', '0772155917', 'irudi@ymail.com', '11-Feb-2022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`AdminID`);

--
-- Indexes for table `book_table`
--
ALTER TABLE `book_table`
  ADD PRIMARY KEY (`BookID`);

--
-- Indexes for table `issued_books`
--
ALTER TABLE `issued_books`
  ADD PRIMARY KEY (`BookID`);

--
-- Indexes for table `login_table`
--
ALTER TABLE `login_table`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `member_table`
--
ALTER TABLE `member_table`
  ADD PRIMARY KEY (`MemberID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
